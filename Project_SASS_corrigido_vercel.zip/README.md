# O Desafio dos 7 Dias: página de vendas

Página estática (HTML, CSS e JavaScript simples, sem build) para vender o e-book
**O Desafio dos 7 Dias**, por Nexus Digital Studio.

## Estrutura

```
.
├── index.html              Página de vendas
├── obrigado.html           Página de agradecimento (depois do pagamento)
├── vercel.json             Cabeçalhos de segurança e cache
├── robots.txt
├── assets/
│   ├── css/
│   │   ├── styles.css      Estilos da página de vendas
│   │   └── obrigado.css    Estilos da página de obrigado
│   ├── js/
│   │   ├── config.js       >>> A CONFIGURAÇÃO: preços, prazo, checkout, depoimentos <<<
│   │   └── main.js         Lógica (preços, contagem, animações). Normalmente não se mexe
│   └── img/                Capa 3D (WebP), imagem para partilha (og-image.jpg), favicon
└── marketing/              Post e story para redes sociais (não vai para o site)
```

## Publicar (GitHub + Vercel)

1. Cria um repositório no GitHub e envia estes ficheiros para a raiz.
2. Na Vercel: **Add New > Project**, escolhe o repositório.
3. Framework Preset: **Other**. Deixa Build Command e Output Directory vazios.
4. Clica em Deploy. Cada `git push` publica automaticamente.

## Antes de divulgar (checklist)

- [ ] **Endereço real:** em `index.html`, troca `SEU-DOMINIO.vercel.app` pelo endereço final
      (aparece em `canonical`, `og:url`, `og:image` e `twitter:image`).
      Sem isto, a imagem não aparece nas pré-visualizações do WhatsApp e do Facebook.
- [ ] **Data da oferta:** em `assets/js/config.js`, confirma `ofertaInicio` (o dia em que a página vai ao ar).
      A oferta dura `ofertaDias` (30) dias e depois a página mostra sozinha o preço normal.
- [ ] **Checkout:** o link está em `buyUrl`. Abre-o no telemóvel e confirma o nome do produto e o preço (500 MT).
      Confirma também que o checkout não mostra avisos que não sejam verdade (por exemplo
      "Black Friday", contagem de tempo própria ou número de compradores).
- [ ] **Página de obrigado:** no RatixPay, define o redirecionamento depois do pagamento para
      `https://O-TEU-ENDERECO/obrigado`, se a plataforma tiver essa opção.
- [ ] **Teste tudo no telemóvel:** todos os botões (comprar, WhatsApp, site) e o menu.
- [ ] **Meta Pixel** (opcional): coloca o ID em `pixelId` antes de anunciar.

## Depoimentos

Em `assets/js/config.js`, na lista `depoimentos`, acrescenta só testemunhos **reais**, com autorização:

```js
depoimentos: [
  { texto: "Texto exato que a pessoa enviou.", nome: "Nome da pessoa", negocio: "Negócio, cidade" }
]
```

- Lista vazia: aparece um convite para os primeiros leitores (`mostrarLancamento: true`).
- Para ver o desenho da secção com textos de exemplo: abre `?preview=depoimentos` no endereço da página.
  Esses textos só aparecem nesse modo e nunca aos visitantes.

## Anúncios (Meta Ads)

Usa endereços com parâmetros, por exemplo:
`https://O-TEU-ENDERECO/?utm_source=facebook&utm_campaign=lancamento`
O nome da campanha vai na mensagem de WhatsApp e no link do checkout.


ESTRUTURA DO DEPLOY
Os ficheiros CSS, JS e imagens ficam na raiz e os caminhos do HTML apontam para essa estrutura.
