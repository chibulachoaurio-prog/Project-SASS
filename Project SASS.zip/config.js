/* =====================================================================
   CONFIGURAÇÃO DA PÁGINA  (é só este ficheiro que precisas de editar)
   ===================================================================== */
window.SITE_CONFIG = {

  /* Contacto */
  whatsapp: "258848641549",            // número com indicativo, sem + nem espaços

  /* Checkout */
  buyUrl: "https://ratixpay.co.mz/checkout.html?produto=Q7HYCR88N",   // deixa "" para os botões abrirem o WhatsApp

  /* Preços */
  price: "500 MT",                     // preço da oferta especial
  oldPrice: "700 MT",                  // preço normal (deixa "" para tirar a oferta)

  /* Prazo da oferta: começa em ofertaInicio e dura ofertaDias dias.
     Quando o prazo acaba, a página mostra sozinha o preço normal.
     Ao publicares, confirma que ofertaInicio é o dia em que a página vai ao ar.
     ofertaDias: 0 = oferta sem prazo (não recomendado). */
  ofertaInicio: "2026-09-21",          // formato AAAA-MM-DD (hora de Maputo)
  ofertaDias: 30,

  /* Meta Ads: ID do Pixel (só números). Vazio = sem Pixel */
  pixelId: "",

  /* DEPOIMENTOS: só REAIS e com autorização da pessoa. Copia o modelo para dentro da lista.
     Exemplo de uma entrada:
       { texto: "Texto exato que a pessoa te enviou.", nome: "Nome da pessoa", negocio: "Negócio, cidade" },
     Enquanto a lista estiver vazia, a secção mostra um convite para os primeiros leitores
     (se mostrarLancamento for true) ou fica escondida (false).
     Para veres o desenho da secção com textos de exemplo: abre a página com ?preview=depoimentos */
  depoimentos: [],
  mostrarLancamento: true
};
