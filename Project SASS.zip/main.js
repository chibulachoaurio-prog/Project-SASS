/* O Desafio dos 7 Dias: lógica da página.  A configuração está em config.js */
(function () {
  "use strict";
  var C = window.SITE_CONFIG || {};
  var qs = new URLSearchParams(location.search);
  var $$ = function (s) { return document.querySelectorAll(s); };
  var num = function (t) { return parseInt(String(t).replace(/[^0-9]/g, ""), 10) || 0; };
  var pad = function (n) { return (n < 10 ? "0" : "") + n; };

  /* ---------- mensagens do WhatsApp (com origem do anúncio) ---------- */
  var origem = qs.get("utm_campaign") || qs.get("utm_source") || "";
  var suf = origem ? " (origem: " + origem + ")" : "";
  var wa = "https://wa.me/" + C.whatsapp + "?text=";
  var msg = function (t) { return encodeURIComponent(t + suf); };

  /* ---------- Pixel da Meta (só se houver pixelId) ---------- */
  if (C.pixelId) {
    !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = "2.0"; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
    fbq("init", C.pixelId); fbq("track", "PageView"); fbq("track", "ViewContent");
  }
  var track = function (ev) { if (window.fbq) fbq("track", ev); };

  /* ---------- oferta e prazo ---------- */
  var deadline = 0;                        // 0 = sem prazo
  if (C.ofertaInicio && C.ofertaDias > 0) {
    var start = new Date(C.ofertaInicio + "T00:00:00+02:00").getTime();   // hora de Maputo
    deadline = start + C.ofertaDias * 864e5;
  }
  var fmtDate = function (ms) {
    return new Date(ms).toLocaleDateString("pt-PT", { day: "numeric", month: "long", timeZone: "Africa/Maputo" });
  };
  var offerOn = function () { return !!C.oldPrice && (!deadline || Date.now() < deadline); };

  function applyPricing() {
    var on = offerOn();
    var shown = on ? C.price : (C.oldPrice || C.price);
    var diff = num(C.oldPrice) - num(C.price);
    var pct = num(C.oldPrice) ? Math.round(diff / num(C.oldPrice) * 100) : 0;
    var hasDeadline = on && !!deadline;
    var lastDay = deadline ? fmtDate(deadline - 1000) : "";

    $$("[data-price]").forEach(function (e) { e.textContent = shown; });
    $$("[data-old]").forEach(function (e) { e.textContent = C.oldPrice; });
    $$("[data-offer]").forEach(function (e) { e.hidden = !on; });
    $$("[data-save-badge]").forEach(function (e) { if (diff > 0) e.textContent = "Poupa " + diff + " MT"; });
    $$("[data-save-text]").forEach(function (e) { if (diff > 0) e.textContent = "Poupas " + diff + " MT" + (pct ? " · " + pct + "% de desconto" : ""); });
    $$("[data-offer-days]").forEach(function (e) { e.textContent = C.ofertaDias ? C.ofertaDias + " dias" : ""; });
    $$("[data-until]").forEach(function (e) { e.textContent = "Oferta válida até " + lastDay; e.hidden = !hasDeadline; });
    $$("[data-until-short]").forEach(function (e) { e.textContent = hasDeadline ? "termina a " + lastDay : ""; });
    $$("[data-until-mini]").forEach(function (e) { e.textContent = hasDeadline ? "até " + lastDay : "oferta especial"; });
    $$("[data-count]").forEach(function (e) { e.hidden = !hasDeadline; });
    if (hasDeadline) tick();
  }

  var timer = 0;
  function tick() {
    var left = deadline - Date.now();
    if (left <= 0) { clearInterval(timer); timer = 0; applyPricing(); return; }
    var d = Math.floor(left / 864e5), h = Math.floor(left % 864e5 / 36e5), m = Math.floor(left % 36e5 / 6e4), s = Math.floor(left % 6e4 / 1e3);
    var v = { d: pad(d), h: pad(h), m: pad(m), s: pad(s) };
    $$("[data-c]").forEach(function (e) { var k = e.getAttribute("data-c"); if (e.textContent !== v[k]) e.textContent = v[k]; });
    if (!timer) timer = setInterval(tick, 1000);
  }
  applyPricing();

  /* ---------- botões: checkout (com UTM) ou WhatsApp ---------- */
  var buyHref = wa + msg("Olá! Quero comprar o e-book O Desafio dos 7 Dias.");
  if (C.buyUrl) {
    try {
      var u = new URL(C.buyUrl);
      ["utm_source", "utm_medium", "utm_campaign", "utm_content"].forEach(function (k) { if (qs.get(k)) u.searchParams.set(k, qs.get(k)); });
      buyHref = u.toString();
    } catch (e) { buyHref = C.buyUrl; }
  }
  $$("[data-buy]").forEach(function (a) {
    a.href = buyHref;
    if (buyHref.indexOf("http") === 0) { a.target = "_blank"; a.rel = "noopener"; }
    a.addEventListener("click", function () { track("InitiateCheckout"); });
  });
  var wire = function (sel, text, ev) {
    $$(sel).forEach(function (a) {
      a.href = wa + msg(text); a.target = "_blank"; a.rel = "noopener";
      a.addEventListener("click", function () { track(ev); });
    });
  };
  wire("[data-help]", "Olá! Tenho uma dúvida sobre o e-book O Desafio dos 7 Dias.", "Contact");
  wire("[data-site]", "Olá! Li o e-book O Desafio dos 7 Dias e quero falar sobre o meu site.", "Lead");
  wire("[data-feedback]", "Olá! Fiz o Desafio dos 7 Dias e quero partilhar o meu feedback.", "Contact");

  /* ---------- depoimentos (só reais) ---------- */
  (function () {
    var sec = document.getElementById("depoimentos"), box = document.getElementById("testsList");
    var list = (C.depoimentos || []).filter(function (t) { return t && t.texto && t.nome; });
    var preview = qs.get("preview") === "depoimentos";
    if (preview) {
      list = [
        { texto: "Aqui vai o depoimento real de um leitor, exatamente como ele escreveu.", nome: "Nome do leitor", negocio: "Negócio, cidade" },
        { texto: "Um segundo depoimento, mais curto.", nome: "Nome do leitor", negocio: "Negócio, cidade" },
        { texto: "O terceiro pode falar de um resultado concreto que a pessoa teve depois de fazer o desafio.", nome: "Nome do leitor", negocio: "Negócio, cidade" }
      ];
      document.getElementById("tPreview").hidden = false;
    }
    if (list.length) {
      list.forEach(function (t) {
        var f = document.createElement("figure"), q = document.createElement("blockquote"), c = document.createElement("figcaption");
        var av = document.createElement("span"), wrap = document.createElement("span"), n = document.createElement("span"), b = document.createElement("span");
        f.className = "tcard"; av.className = "tav"; n.className = "tname"; b.className = "tbiz";
        q.textContent = "\u201C" + t.texto + "\u201D";
        av.textContent = t.nome.split(/\s+/).map(function (p) { return p[0]; }).slice(0, 2).join("").toUpperCase();
        n.textContent = t.nome; b.textContent = t.negocio || "";
        wrap.appendChild(n); if (t.negocio) wrap.appendChild(b);
        c.appendChild(av); c.appendChild(wrap); f.appendChild(q); f.appendChild(c); box.appendChild(f);
      });
      sec.hidden = false;
    } else if (C.mostrarLancamento) {
      document.getElementById("tTitle").textContent = "Sê dos primeiros leitores";
      document.getElementById("tEyebrow").textContent = "Lançamento";
      document.getElementById("launch").hidden = false;
      sec.hidden = false;
    }
  })();

  /* ---------- animações ao rolar (só transform e opacidade) ---------- */
  var targets = document.querySelectorAll(".reveal,#timeline,#scene");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (en) {
      en.forEach(function (x) { if (x.isIntersecting) { x.target.classList.add("in"); io.unobserve(x.target); } });
    }, { threshold: .15, rootMargin: "0px 0px -6% 0px" });
    targets.forEach(function (t) { io.observe(t); });
  } else { targets.forEach(function (t) { t.classList.add("in"); }); }

  /* ---------- barra de progresso ---------- */
  var bar = document.getElementById("progress"), ticking = false;
  function prog() {
    var h = document.documentElement, max = h.scrollHeight - h.clientHeight;
    bar.style.transform = "scaleX(" + (max > 0 ? Math.min(1, h.scrollTop / max) : 0) + ")";
    ticking = false;
  }
  window.addEventListener("scroll", function () { if (!ticking) { ticking = true; requestAnimationFrame(prog); } }, { passive: true });
  prog();

  /* ---------- livro inclina com o rato (só computador) ---------- */
  var stage = document.getElementById("stage"), img = stage && stage.querySelector("img");
  if (stage && matchMedia("(hover:hover) and (pointer:fine)").matches && !matchMedia("(prefers-reduced-motion:reduce)").matches) {
    var raf = 0;
    stage.addEventListener("pointermove", function (e) {
      if (raf) return;
      raf = requestAnimationFrame(function () {
        var r = stage.getBoundingClientRect();
        img.style.setProperty("--ry", (((e.clientX - r.left) / r.width - .5) * 6).toFixed(2) + "deg");
        img.style.setProperty("--rx", ((-((e.clientY - r.top) / r.height - .5)) * 4).toFixed(2) + "deg");
        raf = 0;
      });
    });
    stage.addEventListener("pointerleave", function () { img.style.removeProperty("--ry"); img.style.removeProperty("--rx"); });
  }

  /* ---------- barra de compra no telemóvel ---------- */
  var mbar = document.getElementById("mbar"), hero = document.querySelector(".hero"), buy = document.getElementById("comprar");
  if ("IntersectionObserver" in window) {
    var heroOut = false, buyIn = false;
    var upd = function () { mbar.classList.toggle("show", heroOut && !buyIn); };
    new IntersectionObserver(function (en) { heroOut = !en[0].isIntersecting; upd(); }).observe(hero);
    new IntersectionObserver(function (en) { buyIn = en[0].isIntersecting; upd(); }).observe(buy);
  } else { mbar.classList.add("show"); }
})();
